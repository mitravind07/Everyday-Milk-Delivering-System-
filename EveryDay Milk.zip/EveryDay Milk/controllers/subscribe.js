function handleSubPage(req, res) {
  res.render("sub");
}

module.exports = {
  handleSubPage,
};
