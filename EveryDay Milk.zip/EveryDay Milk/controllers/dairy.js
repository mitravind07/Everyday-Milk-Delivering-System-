function handleDairyPage(req, res) {
  res.render("dairy");
}

module.exports = {
  handleDairyPage,
};
